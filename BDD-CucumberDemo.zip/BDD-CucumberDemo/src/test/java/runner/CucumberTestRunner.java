package runner;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(
         // tags = "",
        features = {"src/test/resources/features/"},
        glue = {"stepdefinition" ,"hooks"  },

plugin = { "pretty"
       ,"html:target/cucumber-report/cucumber.html" ,
       "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
 //      "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
//               ,"usage"
//               , "json:Reports/CucumberTestReport.json"
//              ,  "rerun:Reports/rerun.txt"
       }
        // , tags = "@Ignore"
        , monochrome = true
        		)
 


public class CucumberTestRunner {
 
	

}