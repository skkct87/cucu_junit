package hooks;

import io.cucumber.java.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import base.BaseClass;

public class ApplicationHooks {	
 
	
	 @Before
	 public static void StartExecution( ) { 
		 BaseClass.WebDriverManager();
	 
	  }
	 

    @AfterAll
    public static void EndExecution( )  {
    	BaseClass.tearDown();
    }

    @AfterStep
    public void addScreenshot(Scenario scenario) {

        WebDriver driver =  BaseClass.WebDriverManager();
        if(scenario.isFailed()) {
            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "image");
        }

    }


}
