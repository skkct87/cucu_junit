package stepdefinition;

import pageobjects.HomePage;
import pageobjects.LoginPage;
import pageobjects.PageObjectManager;
import utils.TestSetUp;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;



public class LoginSteps {

    TestSetUp setUp;
    public PageObjectManager pageObjectManager;
    public LoginPage loginPage;
    public HomePage homePage;


	
	 public LoginSteps(TestSetUp setUp) { this.setUp = setUp; this.loginPage =
	  setUp.pageObjectManager.getLoginPage(); this.homePage=
	  setUp.pageObjectManager.getHomePage(); }
	 

    @Given("User is on Home page")
    public void loginTest()  {

    }

    @When("User enters username as {string} and password as {string}")
    public void goToHomePage(String userName, String passWord) throws InterruptedException {

        // login to application
        loginPage.login(userName, passWord);
        Thread.sleep(500);
        // go the next page

    }

    @Then("User should be able to login successfully")
    public void verifyLogin() throws InterruptedException {

        // Verify home page
        Assert.assertTrue(homePage.getHomePageText().contains("Dashboard"));
        Thread.sleep(1000);
        loginPage.logout();
        

    }

    @Then("User should be able to see error message {string}")
    public void verifyErrorMessage(String expectedErrorMessage) throws InterruptedException {

        // Verify home page
        Assert.assertEquals(loginPage.getErrorMessage(),expectedErrorMessage);
        Thread.sleep(500);

    }

}