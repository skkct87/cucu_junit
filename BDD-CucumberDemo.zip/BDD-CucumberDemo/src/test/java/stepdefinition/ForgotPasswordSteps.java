package stepdefinition;


import pageobjects.ForgotPasswordPage;
import pageobjects.LoginPage;
import pageobjects.PageObjectManager;
import utils.TestSetUp;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class ForgotPasswordSteps {

    TestSetUp setUp;
    PageObjectManager pageObjectManager;
    public LoginPage loginPage;
    public  ForgotPasswordPage forgotPasswordPage;

	
	 public ForgotPasswordSteps(TestSetUp setUp) { this.setUp = setUp;
	 this.loginPage = setUp.pageObjectManager.getLoginPage();
	 this.forgotPasswordPage = setUp.pageObjectManager.getForgotPasswordPage(); }
	 

    @When("User clicks on Forgot your password? link")
    public void forgotPasswordLink() throws InterruptedException {

        loginPage.clickOnForgotPasswordLink();
        Thread.sleep(500);

    }

    @Then("User should be able to navigate to Reset Password page")
    public void verifyForgotPasswordPage() throws InterruptedException {

        Assert.assertEquals(forgotPasswordPage.getForgotPageText(),"Reset Password");
        Thread.sleep(500);

    }

    @Then("User clicks on Cancel button to go back to Login Page")
    public void verifyCancelBtn() throws InterruptedException {

        forgotPasswordPage.clickOnCancelBtn();
        Assert.assertEquals(loginPage.getLoginPageTitle(),"Login");
        Thread.sleep(500);

    }

    @Then("User clicks on Reset Password button and provide username as {string}")
    public void verifyResetPasswordBtn(String username) throws InterruptedException {

        forgotPasswordPage.TypeOnUsernameTextBox(username);
        Thread.sleep(500);
        forgotPasswordPage.clickOnRestPasswordBtn();
        Thread.sleep(500);

    }

    @Then("Verify the message {string}")
    public void verifyMessage(String message) throws InterruptedException {

        //  ForgotPasswordPage forgotPasswordPage = setUp.pageObjectManager.getForgotPasswordPage();
        Assert.assertEquals(forgotPasswordPage.getRestMessage(),message);
        Thread.sleep(500);

    }
}


