package utils;

public class Constants {


    public static final int EXPLICIT_WAIT_TIME = 30;

    public static final String CONFIGURATION_FILE_PATH = System.getProperty("user.dir")
            + "/src/test/resources/configs/configuration.properties";

    public static final String SCREENSHOTS_FILEPATH = System.getProperty("user.dir")
            + "/target/screenshot";

}