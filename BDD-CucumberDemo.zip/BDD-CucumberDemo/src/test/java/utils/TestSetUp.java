package utils;

import base.BaseClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pageobjects.PageObjectManager;

public class TestSetUp {

    public WebElement errorMessage;
    public WebElement homePageUserName;
    public PageObjectManager pageObjectManager;
    public BaseClass baseClass;

    public TestSetUp()  {

        baseClass = new BaseClass();
        pageObjectManager = new PageObjectManager(BaseClass.WebDriverManager());

    }
}